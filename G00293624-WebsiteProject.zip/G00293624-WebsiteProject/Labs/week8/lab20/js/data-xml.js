var xhr =new XMLHttpRequest();		//create the XMLHttpRequest object

xhr.onload=function(){
	var response =xhr.responseXML;						//Get XML from server
	var events=response.getElementsByTagName('event');	//find <event> elements

	var di1='map';
	var di2='location';
	var di3='date';
	
	//BUILD UP STRIMG WITH NEW CONTENT(could also use DOM manipulation- see js/data-xml-alt.js from ajax lab3)
	var newContent='';
	for (var i=0;i<events.length;i++){
		newContent+='<div class="event">';
		newContent+='<img src="'+events[i].getElementsByTagName(di1)[0].firstChild.nodeValue+'"';
		newContent+='alt="'+events[i].getElementsByTagName(di2)[0].firstChild.nodeValue+'"/>';
		newContent+='<p><b>'+events[i].getElementsByTagName(di2)[0].firstChild.nodeValue+'</b><br>'
		newContent+=events[i].getElementsByTagName(di3)[0].firstChild.nodeValue+'</p>';
		newContent+='</div>';
	}
	
	//Update page with new content
	document.getElementById('content').innerHTML=newContent;
};

// The final part is the same as the html example but it request an XML file
xhr.open('GET','data/data.xml', true);	//Prepare the request
xhr.send(null);							//send the request