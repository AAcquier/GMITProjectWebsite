<!DOCTYPE html>
<html>
<head>
	<title>Cookies</title>	
</head>
<body>
	<?php
		if (isset($_POST["add"])){
			if (isset($_POST['username'])){
				//ad userneme from a form. Cookie expires in 1 hour
				setcookie("username",$_POST['username'], time() +3600);
			}
		}
		/* Add username to a cookie. This code will be invoked when the "Add to cookie" button is clicked.
		   The cookie should be set to expire after 1 hour. 	
		   HINT: refer to slide 32 of PHP Lecture on moodle */
		if (isset($_POST["clear"])){
			unset($_COOKIE["username"]);
			setcookie("username","x",time()-1);
			/*unset the cookie, just unsets it for the current request so its not available. 
			Need to expire it, to destroy it - setcookie method needed. Any value will do - 
			used x in this example*/
		}
		
		/* Add code which is invoked when the "Clear Cookie" button is clicked
		   The code should ensure the Cookie is destroyed 
		   HINT: refer to slide 32 of PHP Lecture on moodle */
		   
	?>
	
	<form action="storage.php" method="post">
		<input type="text" name="username">
		<input type="submit" name="add" value="Add to cookie">
		<input type="submit" name="clear" value="Clear Cookie">
	</form>
	<br>
	<form action="welcome.php">
		<input type="submit" name="welcome" value="Go to welcome page">
	</form>
	
</body>
</html>
	
