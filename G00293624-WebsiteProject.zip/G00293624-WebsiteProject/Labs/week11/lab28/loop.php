<?php
for($i=1;$i<=5;$i++){
	// ("Number: ".($i+1)."ln"){
	echo nl2br("Number: ".$i."\n");
}
?>