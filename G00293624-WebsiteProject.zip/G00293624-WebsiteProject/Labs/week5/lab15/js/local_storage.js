// add javascript code here for web storage lab exercise
function book(name){
	this.name=name;
	//alert(this.name);
}

function add(){
	var obj_key="obj_key_"+localStorage.length;
	//alert(obj_key);
	localStorage.setItem(obj_key, JSON.stringify(new book(document.book_form.bookName.value)));
	alert(localStorage.length);
	window.location.reload();
	
}

function clear_storage(){
	localStorage.clear();
}

function fromStorage(){
	var i;
	for(i=0; i<localStorage.length;i++){
		var parsedObject=JSON.parse(localStorage.getItem("obj_key_"+i))
		alert(parsedObject.name);
	}
}