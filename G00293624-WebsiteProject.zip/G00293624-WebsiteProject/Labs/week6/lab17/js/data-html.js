var xhr= new XMLHttpRequest(); //creaet ajax object
xhr.open('GET', 'data/data.html', true); 	//CREATE REQUEST
xhr.send(null);	//send request

//process response
xhr.onload=function(){
	document.getElementById('content').innerHTML=xhr.responseText;
}