var num = 2.9999;



//add a comment here giving details of the error this produces
//Uncaught RangeError: toFixed() digits argument must be between 0 and 20(…)
//This tell error message tells rhat the toFixed funtion can not further than 20 decimal point

//add code to handle this error - see Javascript Exception Handling Lab for example on how to do this.

try {
document.writeln(num.toFixed(25));
}
catch (e){
	alert("Error Caught")
}
finally{
	alert("Code of the final block executed.")

}
 
	