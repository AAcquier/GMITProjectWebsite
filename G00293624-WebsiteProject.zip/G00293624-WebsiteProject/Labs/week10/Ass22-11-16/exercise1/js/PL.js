var xhr=new XMLHttpRequest();

xhr.onload=function(){
	responseObject=JSON.parse(xhr.responseText);
	
	var newContent='<tr><th>Pos</th><th>Team</th><th>P</th><th>Pts</th><th>F</th><th>A</th><th>GD</th><th>W</th><th>D</th><th>L</th></tr>';
	
	for (var i=0;i<=5;i++){
		
		newContent+='<tr><td>'+responseObject.standing[i].Pos+'</td>';
		newContent+='<td>'+responseObject.standing[i].Team+'</td>';
		newContent+='<td>'+responseObject.standing[i].P+'</td>';
		newContent+='<td>'+responseObject.standing[i].Pts+'</td>';
		newContent+='<td>'+responseObject.standing[i].F+'</td>';
		newContent+='<td>'+responseObject.standing[i].A+'</td>';
		newContent+='<td>'+responseObject.standing[i].GD+'</td>';
		newContent+='<td>'+responseObject.standing[i].W+'</td>';
		newContent+='<td>'+responseObject.standing[i].D+'</td>';
		newContent+='<td>'+responseObject.standing[i].L+'</td></tr>';
		
	}
	document.getElementById('content').innerHTML=newContent;
}

xhr.open('GET','data/league_table.json',true);
xhr.send(null);