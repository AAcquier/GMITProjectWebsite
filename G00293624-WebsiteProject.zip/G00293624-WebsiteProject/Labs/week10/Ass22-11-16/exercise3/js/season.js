$(document).ready(function(){
	var $newContent='';
	
	$.ajax({
		url:'https://rawgit.com/obrienke1/web_application_development/master/jsonp.js?callback=showSeasons',
		jsonp:'callback',
		dataType:'jsonp',
		jsonpCallback:'showSeasons',
		success: function showSeasons(jsonp){
			
			$.each(jsonp.seasons,function($i){
				$newContent+='<li class="big">'+jsonp.seasons[$i].season+'</li>';
			});
			
		$('#content').html($newContent);
		},
		error:function(){
			alert('The JSONP file could not be accessed.');
		}

	})
	
});

$(".big").hover(function(){
	$(this).css("background-color", "grey");
},function(){
	$(this).css("font-size","2em");
});