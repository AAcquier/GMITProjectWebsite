<?php
if(isset($_POST["submit"])){
//Setting the address cookie
if (isset($_POST['address'])){
		setcookie("Address",$_POST['address'], time() +3600);
	}
	
		//Function generating the order ID
		function randOrdNum($length=3){
			//Give the current year
			$year=date("Y");
			
			//This generate a ramdom string
			$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$charactersLength = strlen($characters);
			$randomString = '';
			for ($i = 0; $i < $length; $i++) {
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}

			//This generate a random number
			$randNum = rand (1,1000000000);
			
			$randNumID= $year . '-' . $randomString . '-' . $randNum;
			return $randNumID;
		}
		
		
		$x=randOrdNum(); //Generating the order ID
		
		//Setting the orderID cookie
		if (!isset($_COOKIE["orderID"])){
			setcookie("orderID",$x ,time() +3600);
		}
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>The Sports Shop</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="js/jquery.creditCardValidator.js"></script>
		<script type="text/javascript" src="js/jquery.shop.js"></script>
		<style>
			body{
				background-color:#FFE4C4;
				}
				
			p3{
				font-size:1.5em;
				}
			
			p31{
				font-size:1.5em;
				color:red;
				}
				
			#paymentType{
				margin-left: 9em;
				}
		</style>
	</head>
	<body>
		<div id="site">
			<header>
				<title> The Sport Shop</title>
				<a href="index.html"><h1><img src="logo.jpg" alt="The Lion Sport Shop logo" width="120" height="80"></a><br></br> The Sports Shop</h1></a>
				<h2> Check Out</h2>
			</header>
			<div id="total"><br>
				<center><strong><p31 id="total2BPaid"> The total to be paid is &euro;_______ </p31></strong></center><br>
			</div>
			<div id="paymentType">
				<strong><p3>Please Select Your Method Of Payment:</p3></strong><br><br>
				<form  action="confirmation.php" method="post">
					<!--this allow to select a payment type-->
					<input type="radio" name="paymentProvider" value="Visa" id="v"> <strong>Visa</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="radio" name="paymentProvider" value="Mastercard" id="m"> <strong>Mastercard </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="radio" name="paymentProvider" value="VisaDebit" id="vd"><strong>Visa Debit</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="radio" name="paymentProvider" value="Paypal" id="p"> <strong>Paypal</strong><br><br>
					<strong><p3>Please enter the card and CVV number</p3></strong><br><br>
					<!--This allow to input the card number-->
					<strong>Card Number: <br></strong><input type="text" name="Cardnumber" value="5105105105105100" id="cn"><br><br>
					<!--This allow to input the CVV number-->
					<strong>CVV:      </strong>   <br><input type="text" name="Cardnumber" value="" id="cvv"><br><br>
					<strong><p3>Please Enter The Name Of The Cardholder:</p3></strong><br><br>
					<!--This allow to input the cardholder first name-->
					<strong>First name:</strong><br>
					<input type="text" name="firstname" value="" id="fn"><br><br>
					<!--This allow to input the cardholder last name-->
					<strong>Last name:</strong><br>
					<input type="text" name="lastname" value="" id="ln"><br><br>
					<!--This allow to input the address of the cardholder-->
					<strong>Please Input The Address Of The Cardholder:</strong><br>
					<textarea rows="5" cols="50" id="add" name="address"></textarea><br>
					<!--Button which allows the transfer of data for payment-->
					<br><center><button type="submit" value="Submit" onclick="finish()" name="submit" class="btn"><font size ="5">Submit</font></button><center></br>
				</form>
			</div>
			<footer>
			Copyright &copy; The Lion Sports Shop 2016
			</footer>
		</div>
    </body>
</html>